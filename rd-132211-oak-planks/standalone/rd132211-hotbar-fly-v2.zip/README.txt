DELETE YOUR OLD FOLDER. Extract this zip fresh.

Run START-HERE.bat

CONTROLS (watch the black console window for "Selected" / "FLY ON"):
  1 / 2 / 3     Rock / Grass / Oak Planks
  Mouse wheel   also changes block
  F or G        toggle fly
  Space / Shift fly up / down
  WASD move, LMB place, RMB break, Enter save, Esc quit

You MUST see a hotbar at the bottom (3 colored squares).
Yellow badge top-left = flying.
