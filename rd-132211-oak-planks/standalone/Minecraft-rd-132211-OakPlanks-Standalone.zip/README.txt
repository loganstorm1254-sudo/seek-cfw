Minecraft rd-132211 (oak planks mod) — standalone

IF THE WINDOW FLASHES CLOSED:
  Double-click Run.bat instead of the exe.
  Then open launch.log in this folder and read the error.

NORMAL RUN:
  1. Unzip this WHOLE folder (keep exe + lib + natives together)
  2. Double-click Run.bat  (or Minecraft-rd-132211-OakPlanks.exe)
  3. Needs Java 8 — uses Prism's jre-legacy automatically if present

CONTROLS: Left click place, Right click break, Enter save
World: gamedata\level.dat
MOD: place on top of grass = oak planks; no height revert
