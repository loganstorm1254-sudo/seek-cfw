EXTRACT THE WHOLE ZIP, then run START-HERE.bat

CONTROLS
  1 / 2 / 3   select Rock / Grass / Oak Planks (hotbar)
  F           toggle fly mode
  Space       jump (or fly up)
  Shift       fly down
  WASD        move
  LMB place / RMB break
  Enter       save
  Esc         quit

Needs Java 8 (Prism jre-legacy is fine).
