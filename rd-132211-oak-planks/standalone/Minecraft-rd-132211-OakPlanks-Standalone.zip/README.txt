EXTRACT THE WHOLE ZIP FIRST

Then double-click:  START-HERE.bat

You should see folders named lib and natives next to that file.
If you only have an .exe, you downloaded the wrong thing — get the .zip and extract it.

Needs Java 8 (Prism's jre-legacy is fine).
