Minecraft rd-132211 (oak planks mod) — standalone, no Prism

HOW TO RUN
1. Unzip this folder anywhere.
2. Double-click Minecraft-rd-132211-OakPlanks.exe
3. It uses Java 8 from Prism if present:
   %AppData%\Roaming\PrismLauncher\java\jre-legacy\bin\javaw.exe
   Or any Java on PATH / JAVA_HOME.

CONTROLS
- Left click: place block
- Right click: break block
- Enter: save world (level.dat in gamedata\)

MOD
- Place one block above grass (top of grass) = oak planks
- No height-based grass/stone revert

Keep this layout:
  Minecraft-rd-132211-OakPlanks.exe
  lib\
  natives\
  gamedata\   (created automatically)
