@echo off
cd /d "%~dp0"
echo Starting Minecraft rd-132211...
Minecraft-rd-132211-OakPlanks.exe
echo.
if exist launch.log (
  echo ===== launch.log =====
  type launch.log
  echo ======================
)
echo.
pause
